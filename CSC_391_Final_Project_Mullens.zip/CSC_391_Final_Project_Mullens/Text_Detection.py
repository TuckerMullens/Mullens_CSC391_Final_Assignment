import cv2
import pytesseract
import re

#Opening the dictionary text file
with open('Dictionary.txt', 'r') as f:
    #Reading in the image and applying resizing or thresholding if necessary
    img = cv2.imread('C:/Users/manly/Documents/Text Recognition Data/12.jpg', 0)
    #img = cv2.resize(img, (0, 0), fx=0.3, fy=0.3)
    #img = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 99, 2)

    #Displaying the image
    cv2.imshow('yee', img)
    cv2.waitKey(0)

    #Detecting the text in the image and returning it
    input = pytesseract.image_to_string(img)

    print("Approximate English Reading: ")

    #Printing the text detected in the image
    extract = re.findall(r'\w+', input)

    for e in extract:
        print(e, end=" ")

    print()

    print("Approximate Spanish Translation: ")

    #Comparing each word in the detected text to lines in the dictionary
    for i in range(0, len(extract)):
        f.seek(0)
        for line in f.readlines():
            translate = []
            line = re.findall(r'\w+', line)
            if((extract[i].lower()) == line[0]):
                translate.append(line[1:])
                break
            else:
                translate = "No word found"
        #printing out translated results
        print("(", end="")
        print(translate, end="")
        if i == (len(extract)-1):
            print(")")
        else:
            print(") + ", end="")